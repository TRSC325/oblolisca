use obelisk::custom_errors::Errors;

fn main() {
    obelisk::logger::init();
    error_test(1);
}

fn error_test(num: i32) -> Result<(), Errors> {
    if num == 1 {
        obelisk::logger::info!("Error");
        return Err(Errors::TestError.into());
    }
    Ok(())
}