pub fn init() {
    env_logger::init()
}

pub use log::*;